<?php

namespace App\Http\Controllers;

use App\add_event;
use Illuminate\Http\Request;

class AddEventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\add_event  $add_event
     * @return \Illuminate\Http\Response
     */
    public function show(add_event $add_event)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\add_event  $add_event
     * @return \Illuminate\Http\Response
     */
    public function edit(add_event $add_event)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\add_event  $add_event
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, add_event $add_event)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\add_event  $add_event
     * @return \Illuminate\Http\Response
     */
    public function destroy(add_event $add_event)
    {
        //
    }
}
