<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_event extends Model
{
    //
    protected $guarded = array();
    /*protected $fillable = ['name', 'skills', 'img','disc'];
    public function getNameAttribute($value)
    {
        return ucFirst($value);
    } */
}
